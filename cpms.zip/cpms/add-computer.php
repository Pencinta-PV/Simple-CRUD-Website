<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['ccmsaid']==0)) {
  header('location:logout.php');
  } else{
    if(isset($_POST['submit']))
  {

$cmsaid=$_SESSION['ccmsaid'];
$nama=$_POST['nama'];
$age=$_POST['age'];
$staffid=$_POST['staffid'];
$jawatan=$_POST['jawatan'];
$school=$_POST['school'];
$date=$_POST['date'];
$hantarpendaftar=$_POST['hantarpendaftar'];
$mppu=$_POST['mppu'];
$penilai=$_POST['penilai'];
$jawatankuasa=$_POST['jawatankuasa'];		
$jpu=$_POST['jpu'];
$lantikan=$_POST['lantikan'];
$catatan=$_POST['catatan'];

 $query=mysqli_query($con,"insert into pp(nama,StaffID,jawatan,school,date,hantarpendaftar,mppu,penilai,jawatankuasa,jpu,lantikan,catatan) value('$nama','$staffid','$jawatan','$school','$date','$hantarpendaftar','$mppu','$penilai','$jawatankuasa','$jpu','$lantikan','$catatan')");
		
	

    if ($query) {
    echo '<script>alert("Detail has been added.")</script>';
echo "<script>window.location.href ='add-computer.php'</script>";
  }
  else
    {
         echo '<script>alert("Something Went Wrong. Please try again")</script>';
    }

  
}

?>

<!doctype html>
<html class="no-js" lang="en">

<head>
   
    <title>CCMS Add Personal Data</title>
  

    <link rel="apple-touch-icon" href="apple-icon.png">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>

<body>
    <!-- Left Panel -->

    <?php include_once('includes/sidebar.php');?>

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <?php include_once('includes/header.php');?>

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Lecturer Personal Details</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="dashboard.php">Dashboard</a></li>
                            <li><a href="add-computer.php">Personal Details</a></li>
                            <li class="active">Add</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">


                <div class="row">
                    <div class="col-lg-6">
                       <!-- .card -->

                    </div>
                    <!--/.col-->

                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><strong>Lecturer Personal Details</strong></div>
                            <form name="computer" method="post" action="" enctype="multipart/form-data">
                                <p style="font-size:16px; color:red" align="center"> <?php if($msg){
    echo $msg;
  }  ?> </p>
                            <div class="card-body card-block">
 
                                <div class="form-group"><label for="company" class=" form-control-label">Nama</label><input type="text" name="nama" value="" class="form-control" id="nama" required="true"></div>
                                                                          
                                        
                                            <div class="row form-group">
                                                <div class="col-12">
                                                    <div class="form-group"><label for="city" class=" form-control-label">StaffID</label><input type="text" name="staffid" id="staffid" value="" class="form-control" required="true"></div>
                                                    </div>
                                                    
                                                    </div>
                                                    
								<div class="form-group"><label for="company" class=" form-control-label">Jawatan Terkini</label><input type="text" name="jawatan" value="" class="form-control" id="jawatan" required="true"></div>
								
									<div class="form-group"><label for="company" class=" form-control-label">School</label><input type="text" name="school" value="" class="form-control" id="school" required="true"></div>
								
								  <div class="form-group"><label for="company" class=" form-control-label">Tarikh Permohonan</label><input type="date" name="date" id="date" class="form-control" required="true"></div>
								
								 
								
							
								
                                 </div>
								
							    <div class="card-header">
									
									<strong>Status</strong>
							    </div>
								
								
								  <div class="card-body card-block">
 
                                <div class="form-group"><label for="company" class=" form-control-label">i.Hantar Ke Pendaftar</label><input type="text" name="hantarpendaftar" value="" class="form-control" id="hantarpendaftar" ></div>
                                                                          
                                <div class="form-group"><label for="company" class=" form-control-label">ii.Mesyuarat PPU</label><input type="text" name="mppu" value="" class="form-control" id="mppu" ></div>
								
							    <div class="form-group"><label for="company" class=" form-control-label">iii.Hantar Ke Penilai</label><input type="text" name="penilai" value="" class="form-control" id="penilai" ></div>
									  
								<div class="form-group"><label for="company" class=" form-control-label">iv.Mesyuarat Jawatankuasa</label><input type="text" name="jawatankuasa" value="" class="form-control" id="jawatankuasa" ></div>
									  
								<div class="form-group"><label for="company" class=" form-control-label">v.Mesyuarat JPU</label><input type="text" name="jpu" value="" class="form-control" id="jpu" ></div>
									  
								<div class="form-group"><label for="company" class=" form-control-label">vi.Tarikh Sah Lantikan</label><input type="text" name="lantikan" value="" class="form-control" id="lantikan" ></div>
									  
								<div class="form-group">
								<label for="exampleFormControlTextarea1">Catatan</label>
								<textarea class="form-control" id="catatan" rows="3" name="catatan"></textarea>
							   </div>
								
                                 </div>
								
								
                                                    
                                                     <div class="card-footer">
                                                       <p style="text-align: center;"><button type="submit" class="btn btn-primary btn-sm" name="submit" id="submit">
                                                            <i class="fa fa-dot-circle-o"></i>  Tambah
                                                        </button></p>
                                                        
                                                    </div>
                                                </div>
                                                </form>
                                            </div>



                                           
                                            </div>
                                        </div><!-- .animated -->
                                    </div><!-- .content -->
                                </div><!-- /#right-panel -->
                                <!-- Right Panel -->


                            <script src="vendors/jquery/dist/jquery.min.js"></script>
                            <script src="vendors/popper.js/dist/umd/popper.min.js"></script>

                            <script src="vendors/jquery-validation/dist/jquery.validate.min.js"></script>
                            <script src="vendors/jquery-validation-unobtrusive/dist/jquery.validate.unobtrusive.min.js"></script>

                            <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
                            <script src="assets/js/main.js"></script>
</body>
</html>
<?php }  ?>
<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['ccmsaid']==0)) {
  header('location:logout.php');
  } else{
    if(isset($_POST['submit']))
  {
$eid=$_GET['editid'];
$cmsaid=$_SESSION['ccmsaid'];
$name=$_POST['nama'];
$StaffID=$_POST['StaffID'];
$jawatan=$_POST['jawatan'];
$school=$_POST['school'];
$date=$_POST['date'];
$hantarpendaftar=$_POST['hantarpendaftar'];
$mppu=$_POST['mppu'];
$penilai=$_POST['penilai'];
$jawatankuasa=$_POST['jawatankuasa'];		
$jpu=$_POST['jpu'];
$lantikan=$_POST['lantikan'];
$catatan=$_POST['catatan'];		
		
		
 $query=mysqli_query($con,"update pp set nama='$nama',StaffID='$StaffID' ,jawatan='$jawatan' ,school='$school' ,date='$date',hantarpendaftar='$hantarpendaftar',mppu='$mppu',penilai='$penilai',jawatankuasa='$jawatankuasa',jpu='$jpu',lantikan='$lantikan',catatan='$catatan' where  ID='$eid' ");

    if ($query) {
    $msg="Detail has been update.";
  }
  else
    {
      $msg="Something Went Wrong. Please try again";
    }

  
}

?>

<!doctype html>
<html class="no-js" lang="en">

<head>
   
    <title>CCMS View Lect Details</title>
  
    <link rel="apple-touch-icon" href="apple-icon.png">
  


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>

<body>
    <!-- Left Panel -->

    <?php include_once('includes/sidebar.php');?>

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <?php include_once('includes/header.php');?>

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>View Lecturer Personal Detail</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="dashboard.php">Dashboard</a></li>
                            <li><a href="manage-computer.php">Manage Personal Data</a></li>
                            <li class="active">View Lecturer Personal Data</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">


                <div class="row">
                    <div class="col-lg-6">
                       <!-- .card -->

                    </div>
                    <!--/.col-->

                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><strong>Lecturer Personal Detail</strong></div>
                            <form name="package" method="post" action="">
                                <p style="font-size:16px; color:red" align="center"> <?php if($msg){
    echo $msg;
  }  ?> </p>
                            <div class="card-body card-block">
 <?php
 $cid=$_GET['editid'];
$ret=mysqli_query($con,"select * from  pp where ID='$cid'");
$cnt=1;
while ($row=mysqli_fetch_array($ret)) {

?>
                                <table border="1" class="table table-bordered mg-b-0">
   
   <tr>
                                <th>Name</th>
                                   <td><?php  echo $row['nama'];?></td>
                                   </tr>                             
<tr>
                              
                                                          
                                    <tr>
                               <th>Staff ID</th>
                                <td><?php  echo $row['StaffID'];?></td>
                            </tr>
									
							 <tr>
                               <th>Jawatan</th>
                                <td><?php  echo $row['jawatan'];?></td>
                            </tr>
                                   
                                <tr>
                               <th>School</th>
                                <td><?php  echo $row['school'];?></td>
                            </tr>                
           
								<tr>
                               <th>Tarikh Permohonan</th>
                                <td><?php  echo $row['date'];?></td>
                               </tr>
                     
 								<tr>
                               <th>Hantar Pendaftar</th>
                                <td><?php  echo $row['hantarpendaftar'];?></td>
                               </tr>
									
								<tr>
                               <th>Mesyuarat PPU</th>
                                <td><?php  echo $row['mppu'];?></td>
                               </tr>
									
								<tr>
                               <th>Hantar Ke Penilai</th>
                                <td><?php  echo $row['penilai'];?></td>
                               </tr>	
								
								<tr>
                               <th>Mesyuarat Jawatan Kuasa</th>
                                <td><?php  echo $row['jawatankuasa'];?></td>
                               </tr>
									
								<tr>
                               <th>Mesyuarat JPU</th>
                                <td><?php  echo $row['jpu'];?></td>
                               </tr>
									
								<tr>
                               <th>Tarikh Lantikan</th>
                                <td><?php  echo $row['lantikan'];?></td>
                               </tr>
									
								<tr>
                               <th>Catatan</th>
                                <td><?php  echo $row['catatan'];?></td>
                               </tr>	
	


   
</table>
                                                    </div>
                                                    
                                                    
                                                    
                                                    
                                                </div>
                                                </table>

<?php } ?>
</table>


  

  

<?php } ?>

                                            </div>



                                           
                                            </div>
                                        </div><!-- .animated -->
                                    </div><!-- .content -->
                                </div><!-- /#right-panel -->
                                <!-- Right Panel -->


                            <script src="vendors/jquery/dist/jquery.min.js"></script>
                            <script src="vendors/popper.js/dist/umd/popper.min.js"></script>

                            <script src="vendors/jquery-validation/dist/jquery.validate.min.js"></script>
                            <script src="vendors/jquery-validation-unobtrusive/dist/jquery.validate.unobtrusive.min.js"></script>

                            <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
                            <script src="assets/js/main.js"></script>
</body>
</html>

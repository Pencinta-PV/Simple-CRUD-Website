<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

$id=$_GET['del'];
$query="DELETE FROM pp WHERE ID=$id";
$result=mysqli_query($con,$query);
if($result){
	 echo '<script>alert("Detail has been deleted.")</script>';
echo "<script>window.location.href ='manage-computer.php'</script>";
	
}else{
	echo "Delete data fail";
}
	

	
  ?>